# theater-management-app
An application for browsing available shows, buying tickets and administering it.
